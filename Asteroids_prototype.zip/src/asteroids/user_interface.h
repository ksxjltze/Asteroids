#pragma once
#include "health.h"

void Asteroids_UI_Init();
void Asteroids_UI_Update(Health hp);

void Asteroids_UI_Draw(Health hp);
void Asteroids_UI_Health_HP_Draw(Health hp);
void Asteroids_UI_Health_HP_Init();