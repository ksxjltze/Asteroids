#pragma once
typedef struct Health {
	float current;
	float max;
}Health;