#include "cprocessing.h"
#include "constants.h"
#include "main_menu.h"
#include "init.h"

void Asteroids_GameOver_Init(void);
void Asteroids_GameOver_Update(void);
void Asteroids_GameOver_Exit(void);

void Asteroids_GameOver_Restart(void);
void Asteroids_GameOver_Quit(void);
