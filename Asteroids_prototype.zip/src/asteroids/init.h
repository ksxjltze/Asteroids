#pragma once
#include "cprocessing.h"
#include <time.h>

void Asteroids_Settings_Setup(int win_width, int win_height);
void Asteroids_Menu_Settings_Setup(int win_width, int win_height);