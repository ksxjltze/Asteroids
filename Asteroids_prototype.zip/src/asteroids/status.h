#pragma once
struct Status {
	int hit;
	float hit_cooldown;
};