#pragma once
#include "cprocessing.h"
int Asteroids_Splash_Draw(float duration, CP_Image splash_image);