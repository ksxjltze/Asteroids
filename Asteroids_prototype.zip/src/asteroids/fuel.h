#pragma once

typedef struct Fuel
{
	float current;
	float max;
} Fuel;