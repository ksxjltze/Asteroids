#pragma once
#include "fuel.h"

typedef struct Engine
{
	Fuel fuel;
	float drain_rate; //per second
} Engine;


